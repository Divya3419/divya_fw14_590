export { default as ShoeCard } from "./ShoeCard";
